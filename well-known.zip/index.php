<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8" />
    <title>Gerador de Curso em PDF</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="bg-light">
<div class="container mt-5">
    <h1 class="mb-4">Gerador de Curso em PDF</h1>
    <form action="generate.php" method="POST">
        <div class="mb-3">
            <label for="topic" class="form-label">Tema do curso</label>
            <input type="text" class="form-control" id="topic" name="topic" placeholder="Ex: Marketing Digital" required />
        </div>
        <button type="submit" class="btn btn-primary">Gerar Curso</button>
    </form>
</div>
</body>
</html>

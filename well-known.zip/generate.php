<?php
require('fpdf.php');

// Pega o tema enviado pelo formulário
$topic = $_POST['topic'] ?? '';

if (!$topic) {
    die("Tema do curso não fornecido.");
}

// Função para chamar a API OpenRouter e gerar texto
function callOpenRouterAPI($prompt) {
    $url = "https://openrouter.ai/api/v1/chat/completions";

    $data = [
        "model" => "gpt-4o-mini",
        "messages" => [
            ["role" => "user", "content" => $prompt]
        ],
        "temperature" => 0.7,
        "max_tokens" => 1000
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Authorization: Bearer SUA_CHAVE_AQUI"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    curl_close($ch);

    $json = json_decode($response, true);

    return $json['choices'][0]['message']['content'] ?? false;
}

// Função para gerar URL de imagem via modelo de imagem
function gerarImagemCurso($tema) {
    $url = "https://openrouter.ai/api/v1/chat/completions";

    $prompt = "Gere uma URL de imagem representativa para um curso sobre: $tema. Responda apenas com uma URL de imagem direta e válida (formato .jpg ou .png).";

    $data = [
        "model" => "openai/gpt-4-vision-preview",
        "messages" => [
            ["role" => "user", "content" => $prompt]
        ],
        "temperature" => 0.7,
        "max_tokens" => 100
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Content-Type: application/json",
        "Authorization: Bearer SUA_CHAVE_AQUI"
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

    $response = curl_exec($ch);
    curl_close($ch);

    $json = json_decode($response, true);

    $content = $json['choices'][0]['message']['content'] ?? '';
    if (preg_match('/https?:\/\/[^\s]+(?:\.jpg|\.png)/', $content, $match)) {
        return $match[0];
    }

    return null;
}

// Prompt principal
$promptCurso = "Crie um curso introdutório sobre {$topic}, dividido em 3 módulos, com tópicos e breve explicação para cada módulo. Termine com exercícios simples.";

// Gera conteúdo
$textoCurso = callOpenRouterAPI($promptCurso);
if (!$textoCurso) die("Erro ao gerar o conteúdo do curso.");

// Gera imagem
$urlImagem = gerarImagemCurso($topic);
$tempImagePath = null;

if ($urlImagem) {
    $tempImagePath = 'imagem_temp.jpg';
    file_put_contents($tempImagePath, file_get_contents($urlImagem));
}

// Geração do PDF
$pdf = new FPDF();
$pdf->AddPage();

// Insere imagem (se existir)
if ($tempImagePath && file_exists($tempImagePath)) {
    $pdf->Image($tempImagePath, 30, 20, 150);
    $pdf->Ln(100);
}

$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, utf8_decode("Curso: {$topic}"), 0, 1, 'C');
$pdf->Ln(5);
$pdf->SetFont('Arial', '', 12);

$linhas = explode("\n", $textoCurso);

foreach ($linhas as $linha) {
    $linha = trim($linha);
    if (empty($linha)) continue;

    if (preg_match('/^#+\s*(.*)/', $linha, $matches)) {
        $pdf->SetFont('Arial', 'B', 14);
        $pdf->Ln(4);
        $pdf->MultiCell(0, 8, utf8_decode($matches[1]));
        $pdf->Ln(2);
        $pdf->SetFont('Arial', '', 12);
    }
    elseif (preg_match('/^(\*|-)\s*(.*)/', $linha, $matches)) {
        $pdf->MultiCell(0, 8, utf8_decode("• " . $matches[2]));
    }
    else {
        $pdf->MultiCell(0, 8, utf8_decode($linha));
    }
}

if ($tempImagePath && file_exists($tempImagePath)) {
    unlink($tempImagePath);
}

$pdf->Output('D', "curso_{$topic}.pdf");
